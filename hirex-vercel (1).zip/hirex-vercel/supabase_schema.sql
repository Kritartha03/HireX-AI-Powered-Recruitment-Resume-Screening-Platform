-- ─── HireX — Supabase Schema ─────────────────────────────────────────────────
-- Run this in your Supabase project → SQL Editor

-- Users
CREATE TABLE IF NOT EXISTS users (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(100)  NOT NULL,
    email      VARCHAR(150)  NOT NULL UNIQUE,
    password   VARCHAR(64)   NOT NULL,
    role       VARCHAR(20)   NOT NULL CHECK (role IN ('jobseeker', 'recruiter')),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Jobs
CREATE TABLE IF NOT EXISTS jobs (
    id               SERIAL PRIMARY KEY,
    recruiter_id     INT          NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title            VARCHAR(200) NOT NULL,
    company          VARCHAR(200) NOT NULL,
    location         VARCHAR(200),
    job_type         VARCHAR(50)  DEFAULT 'Full-time',
    description      TEXT         NOT NULL,
    required_skills  TEXT         NOT NULL,
    experience_years INT          DEFAULT 0,
    salary_min       INT,
    salary_max       INT,
    status           VARCHAR(20)  DEFAULT 'open',
    created_at       TIMESTAMP    DEFAULT NOW()
);

-- Resumes
CREATE TABLE IF NOT EXISTS resumes (
    id               SERIAL PRIMARY KEY,
    user_id          INT          NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    filename         VARCHAR(300) NOT NULL,
    file_url         TEXT,
    extracted_text   TEXT,
    skills           TEXT,
    experience_years FLOAT        DEFAULT 0,
    education        VARCHAR(100),
    vector_data      TEXT,
    uploaded_at      TIMESTAMP    DEFAULT NOW()
);

-- Applications
CREATE TABLE IF NOT EXISTS applications (
    id           SERIAL PRIMARY KEY,
    job_id       INT         NOT NULL REFERENCES jobs(id)    ON DELETE CASCADE,
    user_id      INT         NOT NULL REFERENCES users(id)   ON DELETE CASCADE,
    resume_id    INT         NOT NULL REFERENCES resumes(id) ON DELETE CASCADE,
    match_score  FLOAT       DEFAULT 0,
    skill_gap    TEXT,
    status       VARCHAR(20) DEFAULT 'applied',
    applied_at   TIMESTAMP   DEFAULT NOW()
);

-- ─── Storage bucket ───────────────────────────────────────────────────────────
-- In Supabase dashboard → Storage → Create bucket named "resumes"
-- Set it to PRIVATE (the backend uses the service key to access it)
