# HireX — Vercel + Supabase Deployment Guide

## Architecture

```
Vercel (single deployment)
├── public/          → Static HTML/CSS/JS  (served at /)
├── api/index.py     → Flask serverless    (served at /api/*)
└── backend/         → Python source

Supabase
├── PostgreSQL       → users, jobs, resumes, applications
└── Storage          → uploaded resume files (bucket: "resumes")
```

---

## Step 1 — Set up Supabase

1. Go to [supabase.com](https://supabase.com) → **New project**
2. Note your **Project URL** and **Project Ref** from Project Settings → General
3. Open **SQL Editor** → paste the contents of `supabase_schema.sql` → **Run**
4. Go to **Storage** → **New bucket** → name it `resumes` → keep it **Private** → Create
5. Go to **Project Settings → API** and copy:
   - **Project URL** (e.g. `https://abcxyz.supabase.co`)
   - **service_role** secret key (under "Project API keys")
6. Go to **Project Settings → Database → Connection string → URI**
   - Copy the **Transaction mode** URI (port `6543`) — best for serverless

---

## Step 2 — Deploy to Vercel

### Option A — Vercel CLI (recommended)

```bash
npm i -g vercel
cd hirex-vercel
vercel
```

Follow the prompts (link to your account, create new project).

### Option B — GitHub

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **New Project** → Import your repo
3. Vercel auto-detects `vercel.json` — no build settings needed

---

## Step 3 — Add Environment Variables in Vercel

In your Vercel project → **Settings → Environment Variables**, add:

| Variable | Value |
|---|---|
| `SUPABASE_URL` | `https://YOUR_REF.supabase.co` |
| `SUPABASE_SERVICE_KEY` | `eyJhbGci...` (service_role key) |
| `SUPABASE_DB_URL` | `postgresql://postgres.REF:PASSWORD@HOST:6543/postgres` |
| `SECRET_KEY` | any random string |

Then **Redeploy** (Deployments tab → ⋯ → Redeploy).

---

## Step 4 — Verify

Visit your Vercel URL:
- `https://your-app.vercel.app/` — landing page
- `https://your-app.vercel.app/api/admin/users` — should return `{"status":"ok","data":[],...}`

---

## Local Development

```bash
pip install -r requirements.txt

# Create a .env file from the example
cp .env.example .env
# Fill in your Supabase credentials

# Run Flask locally
cd backend
python app.py
```

For the frontend locally, open `public/index.html` in a browser. Since `utils.js` uses `/api`, 
you'll need to either:
- Temporarily change `const API = '/api'` back to `'http://localhost:5000/api'` for local dev
- Or use `vercel dev` which runs everything together:

```bash
vercel dev   # serves frontend + API together on localhost:3000
```

---

## What Changed from the Original

| Area | Before | After |
|---|---|---|
| Database | MySQL (pymysql) | Supabase PostgreSQL (psycopg2) |
| File storage | Local filesystem | Supabase Storage bucket |
| Temp files | Saved to `backend/resumes/uploads/` | Written to `/tmp`, deleted after parsing |
| API URL | `http://127.0.0.1:5000/api` | `/api` (same origin) |
| SQL dialect | MySQL (`LIKE`, double-quote strings, `AUTO_INCREMENT`) | PostgreSQL (`ILIKE`, single-quote strings, `SERIAL`, `RETURNING id`) |
| AI/matching | Unchanged ✅ | Unchanged ✅ (pure Python, no sklearn) |
| Frontend HTML | Unchanged ✅ | Unchanged ✅ |
