// ─── CONFIG ───────────────────────────────────────────────────────────────────
// On Vercel, the Flask API is served from the same origin under /api
const API = (window.location.hostname === '127.0.0.1' || window.location.hostname === 'localhost')
    ? 'http://127.0.0.1:5000/api'   // ← local Flask
    : '/api';                         // ← Vercel production

// ─── TOAST ────────────────────────────────────────────────────────────────────
function ensureToastContainer() {
    if (!document.getElementById('toast-container')) {
        const d = document.createElement('div');
        d.id = 'toast-container';
        document.body.appendChild(d);
    }
}

function toast(message, type = 'info', duration = 3500) {
    ensureToastContainer();
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    const icons = { success: '✅', error: '❌', info: 'ℹ️' };
    t.innerHTML = `<span>${icons[type] || '•'}</span><span>${message}</span>`;
    document.getElementById('toast-container').appendChild(t);
    setTimeout(() => {
        t.style.opacity = '0';
        t.style.transform = 'translateX(100%)';
        t.style.transition = '.3s';
        setTimeout(() => t.remove(), 300);
    }, duration);
}

// ─── AUTH STORAGE ─────────────────────────────────────────────────────────────
function setUser(user) {
    localStorage.setItem('hirex_user', JSON.stringify(user));
}

function getUser() {
    try {
        return JSON.parse(localStorage.getItem('hirex_user'));
    } catch {
        return null;
    }
}

function clearUser() {
    localStorage.removeItem('hirex_user');
}

// ─── API HELPER ───────────────────────────────────────────────────────────────
async function apiCall(endpoint, method = 'GET', body = null) {
    const user = getUser();
    const headers = { 'Content-Type': 'application/json' };

    if (user) {
        headers['X-User-Id'] = user.id;
        headers['X-User-Role'] = user.role;
    }

    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);

    try {
        const res = await fetch(API + endpoint, opts);
        const data = await res.json();
        return data;
    } catch (err) {
        console.error('API Error:', err);
        return { status: 'error', message: 'Connection error. Please try again.' };
    }
}

async function apiUpload(endpoint, formData) {
    const user = getUser();
    const headers = {};

    if (user) {
        headers['X-User-Id'] = user.id;
        headers['X-User-Role'] = user.role;
    }

    try {
        const res = await fetch(API + endpoint, {
            method: 'POST',
            headers,
            body: formData
        });
        return await res.json();
    } catch (err) {
        console.error('Upload Error:', err);
        return { status: 'error', message: 'Upload failed. Please try again.' };
    }
}

// ─── AUTH HELPERS ─────────────────────────────────────────────────────────────

function _rootPath() {
    const path = window.location.pathname;
    if (path.includes('/jobseeker/') || path.includes('/recruiter/')) {
        return '../';
    }
    return './';
}

function requireAuth(role) {
    const user = getUser();
    if (!user) {
        window.location.href = _rootPath() + 'index.html';
        return null;
    }
    if (role && user.role !== role) {
        window.location.href = _rootPath() + 'index.html';
        return null;
    }
    return user;
}

function logout() {
    clearUser();
    window.location.href = _rootPath() + 'index.html';
}

// ─── UI HELPERS ───────────────────────────────────────────────────────────────
function showLoading(btn, text = 'Loading...') {
    btn.disabled = true;
    btn._orig = btn.innerHTML;
    btn.innerHTML = `<span class="spinner"></span> ${text}`;
}

function hideLoading(btn) {
    btn.disabled = false;
    btn.innerHTML = btn._orig || btn.innerHTML;
}

function setAlert(el, message, type = 'error') {
    el.className = `alert alert-${type}`;
    el.textContent = message;
    el.classList.remove('hidden');
}

function scoreClass(score) {
    if (score >= 70) return 'high';
    if (score >= 45) return 'mid';
    return 'low';
}

function scoreColor(score) {
    if (score >= 70) return 'var(--green)';
    if (score >= 45) return 'var(--amber)';
    return 'var(--red)';
}

function formatDate(dt) {
    return new Date(dt).toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric'
    });
}

function statusBadge(status) {
    const map = {
        applied:     ['badge-muted',  '📋 Applied'],
        shortlisted: ['badge-green',  '⭐ Shortlisted'],
        rejected:    ['badge-red',    '✗ Rejected'],
        hired:       ['badge-accent', '🎉 Hired'],
        open:        ['badge-green',  '✓ Open'],
        closed:      ['badge-red',    '✗ Closed'],
    };
    const [cls, label] = map[status] || ['badge-muted', status];
    return `<span class="badge ${cls}">${label}</span>`;
}

function skillTagsHtml(skillsStr, type = 'neutral') {
    if (!skillsStr) return '<span class="text-muted text-sm">None listed</span>';
    const skills = typeof skillsStr === 'string'
        ? skillsStr.split(',').map(s => s.trim()).filter(Boolean)
        : skillsStr;
    return skills.map(s => `<span class="skill-tag skill-${type}">${s}</span>`).join('');
}

function scoreCircleHtml(score) {
    const cls = scoreClass(score);
    return `<div class="score-circle ${cls}">
        <span>${score}</span>
        <span style="font-size:10px;font-weight:400">/ 100</span>
    </div>`;
}

function rankBadgeHtml(rank) {
    const cls = rank <= 3 ? `rank-${rank}` : 'rank-other';
    return `<div class="rank-badge ${cls}">#${rank}</div>`;
}

// ─── MODAL ────────────────────────────────────────────────────────────────────
function openModal(id) {
    document.getElementById(id).classList.add('open');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}

document.addEventListener('click', e => {
    if (e.target.classList.contains('modal-backdrop')) {
        e.target.classList.remove('open');
    }
});
