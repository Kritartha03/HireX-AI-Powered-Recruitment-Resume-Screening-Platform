from dotenv import load_dotenv
import os
load_dotenv()
import sys
import json
import hashlib
import uuid
import tempfile

from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename

sys.path.insert(0, os.path.dirname(__file__))
from database import get_db
from resumes.resume_utils import extract_text_from_file, extract_skills, extract_experience_years, extract_education
from resumes.ai_matcher import compute_match_score, analyze_skill_gap, rank_candidates, get_recommendations
from resumes.ai_vectorizer import build_tfidf_vector, vector_to_json
from resumes.ai_preprocessing import preprocess_resume

# ─── Supabase Storage client ──────────────────────────────────────────────────
from supabase import create_client

_supabase = None

def get_storage():
    global _supabase
    if _supabase is None:
        url = os.environ.get('SUPABASE_URL', '')
        key = os.environ.get('SUPABASE_SERVICE_KEY', '')
        _supabase = create_client(url, key)
    return _supabase.storage.from_('resumes')

STORAGE_BUCKET = 'resumes'

# ─── APP SETUP ────────────────────────────────────────────────────────────────

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'hirex-secret-key-2024')
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=False)

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'doc', 'txt'}


@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin',  '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type, X-User-Id, X-User-Role')
    response.headers.add('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
    return response


# ─── HELPERS ──────────────────────────────────────────────────────────────────

def get_current_user():
    try:
        user_id = request.headers.get('X-User-Id')
        role    = request.headers.get('X-User-Role', '')
        if user_id:
            return int(user_id), role
    except Exception:
        pass
    return None, None


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()


def ok(data=None, message="Success"):
    return jsonify({"status": "ok", "message": message, "data": data})


def err(message="Error", code=400):
    return jsonify({"status": "error", "message": message}), code


def row_to_dict(row):
    """Convert psycopg2 RealDictRow to plain dict."""
    return dict(row) if row else None


# ─── AUTH ─────────────────────────────────────────────────────────────────────

@app.route('/api/register', methods=['POST', 'OPTIONS'])
def register():
    if request.method == 'OPTIONS':
        return ok()
    d = request.get_json()
    if not d:
        return err("No data provided")

    name     = d.get('name', '').strip()
    email    = d.get('email', '').strip().lower()
    password = d.get('password', '')
    role     = d.get('role', '')

    if not all([name, email, password, role]):
        return err("All fields required")
    if role not in ['jobseeker', 'recruiter']:
        return err("Invalid role")

    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT id FROM users WHERE email=%s', (email,))
            if c.fetchone():
                return err("Email already exists. Please login instead.")
            c.execute(
                'INSERT INTO users (name, email, password, role) VALUES (%s,%s,%s,%s) RETURNING id',
                (name, email, hash_password(password), role)
            )
            user_id = c.fetchone()['id']
            db.commit()
        return ok({'id': user_id, 'name': name, 'email': email, 'role': role},
                  "Registered successfully")
    except Exception as e:
        db.rollback()
        return err(f"Registration failed: {str(e)}")
    finally:
        db.close()


@app.route('/api/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return ok()
    d = request.get_json()
    if not d:
        return err("No data provided")

    email    = d.get('email', '').strip().lower()
    password = d.get('password', '')
    role     = d.get('role', '')

    db = get_db()
    try:
        with db.cursor() as c:
            c.execute(
                'SELECT * FROM users WHERE email=%s AND password=%s AND role=%s',
                (email, hash_password(password), role)
            )
            user = c.fetchone()
        if not user:
            return err("Invalid credentials. Check email, password and role.", 401)
        u = dict(user)
        return ok({'id': u['id'], 'name': u['name'], 'email': u['email'], 'role': u['role']})
    finally:
        db.close()


@app.route('/api/logout', methods=['POST'])
def logout():
    return ok(message="Logged out")


@app.route('/api/me', methods=['GET'])
def me():
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT id, name, email, role FROM users WHERE id=%s', (user_id,))
            user = c.fetchone()
        if not user:
            return err("User not found", 404)
        return ok(dict(user))
    finally:
        db.close()


# ─── RESUME ───────────────────────────────────────────────────────────────────

@app.route('/api/resume/upload', methods=['POST', 'OPTIONS'])
def upload_resume():
    if request.method == 'OPTIONS':
        return ok()
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    if 'resume' not in request.files:
        return err("No file uploaded")
    file = request.files['resume']
    if not file or not allowed_file(file.filename):
        return err("Invalid file type. Use PDF, DOCX, or TXT")

    filename  = secure_filename(f"{user_id}_{uuid.uuid4().hex[:8]}_{file.filename}")
    file_bytes = file.read()

    # Write to /tmp for text extraction
    tmp_path = os.path.join(tempfile.gettempdir(), filename)
    with open(tmp_path, 'wb') as f:
        f.write(file_bytes)

    try:
        text      = extract_text_from_file(tmp_path)
        skills    = extract_skills(text)
        exp_years = extract_experience_years(text)
        education = extract_education(text)
        vector    = build_tfidf_vector(preprocess_resume(text))
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass

    # Upload to Supabase Storage
    file_url = None
    try:
        storage = get_storage()
        storage.upload(
            path=filename,
            file=file_bytes,
            file_options={"content-type": file.content_type or "application/octet-stream"}
        )
        file_url = f"{os.environ.get('SUPABASE_URL', '')}/storage/v1/object/public/{STORAGE_BUCKET}/{filename}"
    except Exception as e:
        # Non-fatal: we still have extracted text
        print(f"Storage upload warning: {e}")

    db = get_db()
    try:
        with db.cursor() as c:
            c.execute(
                '''INSERT INTO resumes
                   (user_id, filename, file_url, extracted_text, skills, experience_years, education, vector_data)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id''',
                (user_id, filename, file_url, text, ','.join(skills), exp_years, education, vector_to_json(vector))
            )
            resume_id = c.fetchone()['id']
            db.commit()
        return ok({
            'resume_id':        resume_id,
            'skills':           skills,
            'experience_years': exp_years,
            'education':        education,
            'text_preview':     text[:300] + '...' if len(text) > 300 else text
        }, "Resume uploaded and parsed successfully")
    except Exception as e:
        db.rollback()
        return err(f"Upload failed: {str(e)}")
    finally:
        db.close()


@app.route('/api/resume/my', methods=['GET'])
def my_resume():
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute(
                'SELECT id, filename, file_url, skills, experience_years, education, uploaded_at FROM resumes WHERE user_id=%s ORDER BY uploaded_at DESC LIMIT 1',
                (user_id,)
            )
            resume = c.fetchone()
        return ok(dict(resume) if resume else None)
    finally:
        db.close()


# ─── JOBS ─────────────────────────────────────────────────────────────────────

@app.route('/api/jobs', methods=['GET'])
def list_jobs():
    search   = request.args.get('search', '')
    location = request.args.get('location', '')
    db = get_db()
    try:
        with db.cursor() as c:
            query  = "SELECT j.*, u.name as recruiter_name FROM jobs j LEFT JOIN users u ON j.recruiter_id=u.id WHERE j.status='open'"
            params = []
            if search:
                query += ' AND (j.title ILIKE %s OR j.description ILIKE %s OR j.required_skills ILIKE %s)'
                params += [f'%{search}%', f'%{search}%', f'%{search}%']
            if location:
                query += ' AND j.location ILIKE %s'
                params.append(f'%{location}%')
            query += ' ORDER BY j.created_at DESC'
            c.execute(query, params)
            jobs = c.fetchall()
        return ok([dict(j) for j in jobs])
    finally:
        db.close()


@app.route('/api/jobs/my', methods=['GET'])
def my_jobs():
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT * FROM jobs WHERE recruiter_id=%s ORDER BY created_at DESC', (user_id,))
            jobs = c.fetchall()
        return ok([dict(j) for j in jobs])
    finally:
        db.close()


@app.route('/api/jobs/<int:job_id>', methods=['GET'])
def get_job(job_id):
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT * FROM jobs WHERE id=%s', (job_id,))
            job = c.fetchone()
        if not job:
            return err("Job not found", 404)
        return ok(dict(job))
    finally:
        db.close()


@app.route('/api/jobs', methods=['POST', 'OPTIONS'])
def post_job():
    if request.method == 'OPTIONS':
        return ok()
    user_id, role = get_current_user()
    if not user_id or role != 'recruiter':
        return err("Recruiter access required", 403)
    d = request.get_json()
    if not all(d.get(k) for k in ['title', 'company', 'description', 'required_skills']):
        return err("Missing required fields")
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute(
                '''INSERT INTO jobs
                   (recruiter_id, title, company, location, job_type, description,
                    required_skills, experience_years, salary_min, salary_max)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id''',
                (user_id, d['title'], d['company'], d.get('location', ''),
                 d.get('job_type', 'Full-time'), d['description'], d['required_skills'],
                 int(d.get('experience_years', 0)), d.get('salary_min'), d.get('salary_max'))
            )
            job_id = c.fetchone()['id']
            db.commit()
            c.execute('SELECT * FROM jobs WHERE id=%s', (job_id,))
            job = c.fetchone()
        return ok(dict(job), "Job posted successfully")
    except Exception as e:
        db.rollback()
        return err(f"Failed to post job: {str(e)}")
    finally:
        db.close()


@app.route('/api/jobs/<int:job_id>', methods=['DELETE', 'OPTIONS'])
def delete_job(job_id):
    if request.method == 'OPTIONS':
        return ok()
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('DELETE FROM jobs WHERE id=%s AND recruiter_id=%s', (job_id, user_id))
            db.commit()
        return ok(message="Job deleted")
    finally:
        db.close()


# ─── APPLICATIONS ─────────────────────────────────────────────────────────────

@app.route('/api/apply', methods=['POST', 'OPTIONS'])
def apply_job():
    if request.method == 'OPTIONS':
        return ok()
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    d      = request.get_json()
    job_id = d.get('job_id')
    if not job_id:
        return err("job_id required")

    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT * FROM resumes WHERE user_id=%s ORDER BY uploaded_at DESC LIMIT 1', (user_id,))
            resume = c.fetchone()
            if not resume:
                return err("Please upload a resume first")

            c.execute('SELECT * FROM jobs WHERE id=%s', (job_id,))
            job = c.fetchone()
            if not job:
                return err("Job not found", 404)

            c.execute('SELECT id FROM applications WHERE job_id=%s AND user_id=%s', (job_id, user_id))
            if c.fetchone():
                return err("Already applied to this job")

            resume = dict(resume)
            job    = dict(job)

            scores = compute_match_score(
                resume.get('extracted_text', ''), job.get('description', ''),
                resume.get('skills', ''),          job.get('required_skills', ''),
                resume.get('experience_years', 0), job.get('experience_years', 0)
            )
            gap = analyze_skill_gap(resume.get('skills', ''), job.get('required_skills', ''))

            c.execute(
                '''INSERT INTO applications (job_id, user_id, resume_id, match_score, skill_gap)
                   VALUES (%s,%s,%s,%s,%s)''',
                (job_id, user_id, resume['id'], scores['total_score'], json.dumps(gap))
            )
            db.commit()

        return ok({
            'match_score':     scores['total_score'],
            'breakdown':       scores,
            'skill_gap':       gap,
            'recommendations': get_recommendations(gap['missing'])
        }, "Application submitted!")
    except Exception as e:
        db.rollback()
        return err(f"Application failed: {str(e)}")
    finally:
        db.close()


@app.route('/api/applications/my', methods=['GET'])
def my_applications():
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute(
                '''SELECT a.*, j.title, j.company, j.location, j.job_type, j.salary_min, j.salary_max
                   FROM applications a JOIN jobs j ON a.job_id=j.id
                   WHERE a.user_id=%s ORDER BY a.applied_at DESC''',
                (user_id,)
            )
            apps = c.fetchall()
        result = []
        for a in apps:
            row = dict(a)
            try:
                row['skill_gap'] = json.loads(row['skill_gap']) if row.get('skill_gap') else {}
            except Exception:
                row['skill_gap'] = {}
            result.append(row)
        return ok(result)
    finally:
        db.close()


# ─── RECRUITER ────────────────────────────────────────────────────────────────

@app.route('/api/jobs/<int:job_id>/applicants', methods=['GET'])
def job_applicants(job_id):
    user_id, role = get_current_user()
    if not user_id or role != 'recruiter':
        return err("Recruiter access required", 403)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT * FROM jobs WHERE id=%s AND recruiter_id=%s', (job_id, user_id))
            job = c.fetchone()
            if not job:
                return err("Job not found or access denied", 404)

            c.execute(
                '''SELECT a.*, u.name, u.email, r.skills, r.experience_years, r.education
                   FROM applications a
                   JOIN users u   ON a.user_id=u.id
                   JOIN resumes r ON a.resume_id=r.id
                   WHERE a.job_id=%s''',
                (job_id,)
            )
            apps = c.fetchall()

        candidates = []
        for a in apps:
            row = dict(a)
            try:
                row['skill_gap'] = json.loads(row['skill_gap']) if row.get('skill_gap') else {}
            except Exception:
                row['skill_gap'] = {}
            candidates.append(row)

        ranked = rank_candidates(candidates)
        return ok({'job': dict(job), 'candidates': ranked})
    finally:
        db.close()


@app.route('/api/applications/<int:app_id>/status', methods=['PUT', 'OPTIONS'])
def update_application_status(app_id):
    if request.method == 'OPTIONS':
        return ok()
    user_id, role = get_current_user()
    if not user_id or role != 'recruiter':
        return err("Recruiter access required", 403)
    d      = request.get_json()
    status = d.get('status')
    if status not in ['applied', 'shortlisted', 'rejected', 'hired']:
        return err("Invalid status")
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('UPDATE applications SET status=%s WHERE id=%s', (status, app_id))
            db.commit()
        return ok(message=f"Status updated to {status}")
    finally:
        db.close()


# ─── STATS ────────────────────────────────────────────────────────────────────

@app.route('/api/stats/jobseeker', methods=['GET'])
def jobseeker_stats():
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT COUNT(*) as c FROM applications WHERE user_id=%s', (user_id,))
            total_apps = c.fetchone()['c']
            c.execute("SELECT COUNT(*) as c FROM applications WHERE user_id=%s AND status='shortlisted'", (user_id,))
            shortlisted = c.fetchone()['c']
            c.execute('SELECT AVG(match_score) as s FROM applications WHERE user_id=%s', (user_id,))
            avg_score = round(float(c.fetchone()['s'] or 0), 1)
            c.execute('SELECT COUNT(*) as c FROM resumes WHERE user_id=%s', (user_id,))
            has_resume = c.fetchone()['c'] > 0
        return ok({'total_applications': total_apps, 'shortlisted': shortlisted,
                   'avg_match_score': avg_score, 'has_resume': has_resume})
    finally:
        db.close()


@app.route('/api/stats/recruiter', methods=['GET'])
def recruiter_stats():
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT COUNT(*) as c FROM jobs WHERE recruiter_id=%s', (user_id,))
            total_jobs = c.fetchone()['c']
            c.execute(
                'SELECT COUNT(*) as c FROM applications a JOIN jobs j ON a.job_id=j.id WHERE j.recruiter_id=%s',
                (user_id,)
            )
            total_apps = c.fetchone()['c']
            c.execute(
                "SELECT COUNT(*) as c FROM applications a JOIN jobs j ON a.job_id=j.id WHERE j.recruiter_id=%s AND a.status='shortlisted'",
                (user_id,)
            )
            shortlisted = c.fetchone()['c']
        return ok({'total_jobs': total_jobs, 'total_applications': total_apps, 'shortlisted': shortlisted})
    finally:
        db.close()


# ─── SKILL GAP ────────────────────────────────────────────────────────────────

@app.route('/api/skill-gap/<int:job_id>', methods=['GET'])
def skill_gap_analysis(job_id):
    user_id, _ = get_current_user()
    if not user_id:
        return err("Not authenticated", 401)
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT * FROM resumes WHERE user_id=%s ORDER BY uploaded_at DESC LIMIT 1', (user_id,))
            resume = c.fetchone()
            if not resume:
                return err("No resume found")
            c.execute('SELECT * FROM jobs WHERE id=%s', (job_id,))
            job = c.fetchone()
            if not job:
                return err("Job not found", 404)
        resume = dict(resume)
        job    = dict(job)
        gap  = analyze_skill_gap(resume.get('skills', ''), job.get('required_skills', ''))
        recs = get_recommendations(gap['missing'])
        return ok({'gap': gap, 'recommendations': recs, 'job_title': job['title']})
    finally:
        db.close()


# ─── ADMIN ────────────────────────────────────────────────────────────────────

@app.route('/api/admin/users', methods=['GET'])
def admin_users():
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC')
            users = c.fetchall()
        return ok([dict(u) for u in users])
    finally:
        db.close()


@app.route('/api/admin/jobs', methods=['GET'])
def admin_jobs():
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute('SELECT * FROM jobs ORDER BY created_at DESC')
            jobs = c.fetchall()
        return ok([dict(j) for j in jobs])
    finally:
        db.close()


@app.route('/api/admin/applications', methods=['GET'])
def admin_applications():
    db = get_db()
    try:
        with db.cursor() as c:
            c.execute(
                '''SELECT a.id, a.match_score, a.status, a.applied_at,
                          u.name as applicant_name, u.email as applicant_email,
                          j.title as job_title, j.company
                   FROM applications a
                   JOIN users u ON a.user_id = u.id
                   JOIN jobs  j ON a.job_id  = j.id
                   ORDER BY a.applied_at DESC'''
            )
            apps = c.fetchall()
        return ok([dict(a) for a in apps])
    finally:
        db.close()


if __name__ == '__main__':
    app.run(debug=True, port=5000)
