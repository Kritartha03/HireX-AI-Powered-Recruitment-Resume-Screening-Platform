import psycopg2
import psycopg2.extras
import os

# ─── CONFIG ───────────────────────────────────────────────────────────────────
# Set SUPABASE_DB_URL in your Vercel environment variables.
# Format: postgresql://postgres.REF:PASSWORD@HOST:PORT/postgres
DB_URL = os.environ.get('SUPABASE_DB_URL', '')


# ─── CONNECTION ───────────────────────────────────────────────────────────────

def get_db():
    """Get a new PostgreSQL connection with dict-like cursor."""
    conn = psycopg2.connect(
        DB_URL,
        cursor_factory=psycopg2.extras.RealDictCursor,
        sslmode='require'
    )
    return conn


# ─── INIT ─────────────────────────────────────────────────────────────────────

def init_db():
    """
    Tables are created via Supabase SQL Editor using supabase_schema.sql.
    This function is a no-op — kept for compatibility.
    """
    pass
