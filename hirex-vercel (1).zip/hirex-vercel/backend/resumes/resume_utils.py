import re
import os

def extract_text_from_file(filepath):
    """Extract text from PDF or DOCX file."""
    ext = os.path.splitext(filepath)[1].lower()
    text = ""

    if ext == '.pdf':
        try:
            import PyPDF2
            with open(filepath, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text += page.extract_text() or ""
        except Exception as e:
            text = f"Error extracting PDF: {e}"

    elif ext in ['.docx', '.doc']:
        try:
            from docx import Document
            doc = Document(filepath)
            text = "\n".join([para.text for para in doc.paragraphs])
        except Exception as e:
            text = f"Error extracting DOCX: {e}"

    elif ext == '.txt':
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()

    return text.strip()


def extract_skills(text):
    """Extract skills from resume text using keyword matching."""
    SKILL_KEYWORDS = [
        # Programming Languages
        'python', 'java', 'javascript', 'typescript', 'c++', 'c#', 'ruby', 'go', 'rust',
        'php', 'swift', 'kotlin', 'scala', 'r', 'matlab', 'perl',
        # Web
        'html', 'css', 'react', 'angular', 'vue', 'node.js', 'nodejs', 'express',
        'django', 'flask', 'fastapi', 'spring', 'laravel', 'rails',
        # Data & AI
        'machine learning', 'deep learning', 'nlp', 'computer vision', 'tensorflow',
        'pytorch', 'keras', 'scikit-learn', 'pandas', 'numpy', 'matplotlib',
        'data analysis', 'data science', 'statistics', 'tableau', 'power bi',
        # Databases
        'sql', 'mysql', 'postgresql', 'mongodb', 'redis', 'sqlite', 'oracle',
        'elasticsearch', 'cassandra', 'dynamodb',
        # Cloud & DevOps
        'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins', 'terraform',
        'ansible', 'ci/cd', 'git', 'github', 'linux', 'bash',
        # Mobile
        'android', 'ios', 'react native', 'flutter',
        # Soft Skills
        'leadership', 'communication', 'teamwork', 'problem solving', 'agile', 'scrum'
    ]

    text_lower = text.lower()
    found = []
    for skill in SKILL_KEYWORDS:
        if skill in text_lower:
            found.append(skill)
    return list(set(found))


def extract_experience_years(text):
    """Estimate years of experience from resume text."""
    patterns = [
        r'(\d+)\+?\s*years?\s+of\s+experience',
        r'(\d+)\+?\s*years?\s+experience',
        r'experience\s+of\s+(\d+)\+?\s*years?',
        r'(\d{4})\s*[-–]\s*(present|current|\d{4})',
    ]

    total_years = 0
    for pat in patterns[:3]:
        matches = re.findall(pat, text, re.IGNORECASE)
        if matches:
            total_years = max(total_years, max(int(m) for m in matches))

    if total_years == 0:
        date_ranges = re.findall(r'(\d{4})\s*[-–]\s*(present|\d{4})', text, re.IGNORECASE)
        for start, end in date_ranges:
            end_year = 2024 if end.lower() == 'present' else int(end)
            total_years += max(0, end_year - int(start))

    return min(total_years, 40)


def extract_education(text):
    """Extract education level from resume text."""
    text_lower = text.lower()
    if any(w in text_lower for w in ['phd', 'ph.d', 'doctorate', 'doctor of']):
        return 'PhD'
    if any(w in text_lower for w in ['master', 'msc', 'm.sc', 'mba', 'm.b.a', 'me ', 'm.e']):
        return 'Masters'
    if any(w in text_lower for w in ['bachelor', 'bsc', 'b.sc', 'b.e', 'btech', 'b.tech', 'b.a', 'undergraduate']):
        return 'Bachelors'
    if any(w in text_lower for w in ['diploma', 'associate']):
        return 'Diploma'
    return 'Not specified'
