import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from ai_preprocessing import preprocess_resume, preprocess_job_description
from ai_vectorizer import build_tfidf_vector, cosine_similarity, vector_from_json


def compute_match_score(resume_text, job_description, resume_skills, job_skills_str,
                         resume_exp, job_exp_required):
    """
    Compute a comprehensive match score between a resume and job.
    Returns score 0-100 and breakdown dict.
    """
    # 1. Text similarity (50% weight)
    clean_resume = preprocess_resume(resume_text or "")
    clean_job = preprocess_job_description(job_description or "")

    vec_resume = build_tfidf_vector(clean_resume)
    vec_job = build_tfidf_vector(clean_job)
    text_sim = cosine_similarity(vec_resume, vec_job)

    # 2. Skill overlap (35% weight)
    if isinstance(resume_skills, str):
        resume_skill_list = [s.strip().lower() for s in resume_skills.split(',') if s.strip()]
    else:
        resume_skill_list = [s.lower() for s in (resume_skills or [])]

    if isinstance(job_skills_str, str):
        job_skill_list = [s.strip().lower() for s in job_skills_str.split(',') if s.strip()]
    else:
        job_skill_list = [s.lower() for s in (job_skills_str or [])]

    if job_skill_list:
        matched = len(set(resume_skill_list) & set(job_skill_list))
        skill_score = matched / len(job_skill_list)
    else:
        skill_score = 0.5  # neutral if no skills listed

    # 3. Experience score (15% weight)
    exp_score = 1.0
    if job_exp_required and job_exp_required > 0:
        if resume_exp >= job_exp_required:
            exp_score = 1.0
        elif resume_exp >= job_exp_required * 0.7:
            exp_score = 0.7
        else:
            exp_score = max(0.2, resume_exp / job_exp_required)

    # Weighted total
    total = (text_sim * 0.50) + (skill_score * 0.35) + (exp_score * 0.15)
    total_pct = round(total * 100, 1)

    return {
        'total_score': total_pct,
        'text_similarity': round(text_sim * 100, 1),
        'skill_match': round(skill_score * 100, 1),
        'experience_match': round(exp_score * 100, 1)
    }


def analyze_skill_gap(resume_skills, job_skills_str):
    """
    Identify missing skills (gap) and matched skills.
    Returns dict with matched, missing, extra.
    """
    if isinstance(resume_skills, str):
        resume_set = set(s.strip().lower() for s in resume_skills.split(',') if s.strip())
    else:
        resume_set = set(s.lower() for s in (resume_skills or []))

    if isinstance(job_skills_str, str):
        job_set = set(s.strip().lower() for s in job_skills_str.split(',') if s.strip())
    else:
        job_set = set(s.lower() for s in (job_skills_str or []))

    matched = list(resume_set & job_set)
    missing = list(job_set - resume_set)
    extra = list(resume_set - job_set)

    return {
        'matched': sorted(matched),
        'missing': sorted(missing),
        'extra': sorted(extra),
        'coverage_pct': round(len(matched) / len(job_set) * 100, 1) if job_set else 100
    }


def rank_candidates(candidates):
    """
    Rank a list of candidate dicts by match_score descending.
    Each candidate: {user_id, name, email, match_score, skill_gap, resume_id, ...}
    Returns sorted list with rank added.
    """
    sorted_candidates = sorted(candidates, key=lambda x: x.get('match_score', 0), reverse=True)
    for i, c in enumerate(sorted_candidates):
        c['rank'] = i + 1
        score = c.get('match_score', 0)
        if score >= 80:
            c['rating'] = 'Excellent'
        elif score >= 60:
            c['rating'] = 'Good'
        elif score >= 40:
            c['rating'] = 'Fair'
        else:
            c['rating'] = 'Poor'
    return sorted_candidates


def get_recommendations(missing_skills):
    """
    Suggest learning resources for missing skills.
    """
    RESOURCE_MAP = {
        'python': 'Python.org docs, Automate the Boring Stuff (free)',
        'javascript': 'javascript.info, MDN Web Docs',
        'react': 'react.dev official tutorial',
        'machine learning': 'fast.ai, Coursera ML by Andrew Ng',
        'sql': 'SQLZoo, Mode Analytics SQL Tutorial',
        'aws': 'AWS Free Tier + official training',
        'docker': 'Play with Docker (labs.play-with-docker.com)',
        'kubernetes': 'Kubernetes.io interactive tutorial',
        'tensorflow': 'tensorflow.org tutorials',
        'pytorch': 'pytorch.org 60-minute blitz',
        'data analysis': 'Kaggle Learn - Pandas',
        'deep learning': 'fast.ai Practical Deep Learning',
        'nlp': 'Hugging Face NLP course (free)',
        'git': 'learngitbranching.js.org',
        'linux': 'linuxjourney.com',
    }
    recs = {}
    for skill in (missing_skills or []):
        skill_lower = skill.lower()
        for key, val in RESOURCE_MAP.items():
            if key in skill_lower or skill_lower in key:
                recs[skill] = val
                break
        if skill not in recs:
            recs[skill] = f'Search: "{skill} tutorial" on YouTube or Coursera'
    return recs
