import json
import math
import re
from collections import Counter


def tokenize(text):
    """Simple tokenizer - lowercase, remove punctuation, split."""
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s\+#]', ' ', text)
    tokens = text.split()
    # Remove very short tokens
    return [t for t in tokens if len(t) > 1]


def compute_tf(tokens):
    """Compute Term Frequency."""
    count = Counter(tokens)
    total = len(tokens)
    return {term: freq / total for term, freq in count.items()} if total > 0 else {}


def build_tfidf_vector(text, vocabulary=None):
    """
    Build a simple TF-IDF-like vector from text.
    Returns dict of {term: score} and the vocabulary used.
    """
    tokens = tokenize(text)
    tf = compute_tf(tokens)

    # Simple IDF boost for tech terms
    IMPORTANT_TERMS = {
        'python', 'java', 'javascript', 'machine', 'learning', 'data', 'sql',
        'react', 'node', 'aws', 'docker', 'tensorflow', 'pytorch', 'nlp',
        'backend', 'frontend', 'fullstack', 'api', 'database', 'cloud',
        'leadership', 'agile', 'scrum', 'management', 'analysis'
    }

    vector = {}
    for term, score in tf.items():
        idf_boost = 2.0 if term in IMPORTANT_TERMS else 1.0
        vector[term] = score * idf_boost

    return vector


def cosine_similarity(vec_a, vec_b):
    """Compute cosine similarity between two TF-IDF vectors."""
    if not vec_a or not vec_b:
        return 0.0

    common = set(vec_a.keys()) & set(vec_b.keys())
    dot = sum(vec_a[t] * vec_b[t] for t in common)

    mag_a = math.sqrt(sum(v**2 for v in vec_a.values()))
    mag_b = math.sqrt(sum(v**2 for v in vec_b.values()))

    if mag_a == 0 or mag_b == 0:
        return 0.0

    return round(dot / (mag_a * mag_b), 4)


def vector_to_json(vector):
    """Serialize vector to JSON string for DB storage."""
    return json.dumps(vector)


def vector_from_json(json_str):
    """Deserialize vector from JSON string."""
    try:
        return json.loads(json_str)
    except Exception:
        return {}
