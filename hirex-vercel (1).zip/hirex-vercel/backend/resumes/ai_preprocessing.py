import re


STOPWORDS = set([
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your',
    'yours', 'yourself', 'he', 'him', 'his', 'himself', 'she', 'her', 'hers',
    'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 'theirs',
    'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 'these',
    'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have',
    'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the',
    'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at',
    'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through',
    'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down',
    'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then',
    'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'both',
    'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
    'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't',
    'can', 'will', 'just', 'don', 'should', 'now', 'd', 'll', 'm', 'o',
    're', 've', 'y', 'ain', 'aren', 'couldn', 'didn', 'doesn', 'hadn',
    'hasn', 'haven', 'isn', 'ma', 'mightn', 'mustn', 'needn', 'shan',
    'shouldn', 'wasn', 'weren', 'won', 'wouldn'
])


def clean_text(text):
    """Clean and normalize text for NLP processing."""
    if not text:
        return ""

    # Lowercase
    text = text.lower()

    # Preserve important tech terms with special chars
    text = text.replace('c++', 'cplusplus')
    text = text.replace('c#', 'csharp')
    text = text.replace('node.js', 'nodejs')
    text = text.replace('.net', 'dotnet')
    text = text.replace('ci/cd', 'cicd')

    # Remove URLs
    text = re.sub(r'http\S+|www\.\S+', '', text)

    # Remove emails
    text = re.sub(r'\S+@\S+', '', text)

    # Remove phone numbers
    text = re.sub(r'\+?\d[\d\s\-().]{8,}', '', text)

    # Remove special characters except spaces
    text = re.sub(r'[^a-z0-9\s]', ' ', text)

    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text).strip()

    return text


def remove_stopwords(text):
    """Remove stopwords from text."""
    tokens = text.split()
    return ' '.join(t for t in tokens if t not in STOPWORDS)


def preprocess(text):
    """Full preprocessing pipeline."""
    text = clean_text(text)
    text = remove_stopwords(text)
    return text


def preprocess_job_description(jd):
    """Preprocess job description specifically."""
    return preprocess(jd)


def preprocess_resume(resume_text):
    """Preprocess resume text specifically."""
    return preprocess(resume_text)
