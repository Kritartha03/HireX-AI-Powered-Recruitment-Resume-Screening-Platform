"""
Vercel entry point.
Vercel's Python runtime picks up the `app` (WSGI) object from this module.
"""
import sys
import os

# Make sure backend/ is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from backend.app import app  # noqa: F401  — Vercel uses this as the WSGI handler
